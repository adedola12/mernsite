import mongoose from "mongoose";

const takeOffSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    quantity: {
      type: Number,
      required: true,
    },
    unit: {
      type: String,
      required: true,
    },
    userRef: {
      type: String,
      required: true,
    },
  },
  { timestamps: true }
);

const TakeoffData = mongoose.model("TakeOffData", takeOffSchema);

export default TakeoffData;
